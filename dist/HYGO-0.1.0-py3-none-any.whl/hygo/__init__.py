from .HYGO import HYGO
from .population import Population
from .individual import Individual
from .table import Table
